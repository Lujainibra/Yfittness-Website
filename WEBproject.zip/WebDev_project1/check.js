
function Valid() {
    
    if (document.getElementById('firstName').value == "") { //check if firstname is empty, then alert the user the error text
        alert("check the First Name")
		return false
    }

    if (document.getElementById("lastName").value == "") {//check if lastname is empty, then alert the user the error text
        alert("check the Last Name")
		return false
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(document.getElementById("email").value)) {//use regex to check if email is valid
        alert("check the Email")
		return false
    }

    if (!/05\d{7,15}/.test(document.getElementById('phone').value)) { // use regex to valid user phone
        alert("check the Phone Number")
		return false
    }

    if (!["Saudi", "Not-Saudi"].includes(document.getElementById('nationality').value)) { //check if nationality is valid and in the valid list
        alert("check the Nationality")
		return false
    }

    var gender = "";
    for(var i of document.getElementsByName('Gender')){ //loop in all radiobox to know which one the user has selected
        if (i.checked) { //use checked method to return true if this element is selected
            gender = i.value;
        }
    }

    if (!["Man", "Female"].includes(gender)) { //check if the user did not choose female or male, then display "check the Gender"
        alert("check the Gender")
		return false
    }

    var lang = ""
    for(var i of document.getElementsByName('language')){ //loop in all radiobox to know which one the user has selected
        if (i.checked) {
            lang = i.value;
        }
    }

    if (!["English", "French", "Arabic"].includes(lang)) { //check if the user did not choose a language from this list, then display the message
        alert("check the Languages")
		return false
    }

    if (!/\d{4}-\d{2}-\d{2}/.test(document.getElementById("dob").value)) {//use regex to validate the date of birth
        alert("check the Date of birth")
		return false
    }
    if (0 >= document.getElementById("age").value || document.getElementById("age").value > 120) { //check if the age does not belong to the required intervale, then display the error message
        alert("check the Age")
		return false
    }

    if (document.getElementById("message").value == "") { // check if the message is empty
        alert("check the Message")
		return false
    }


    return true

}