 <html>
	<head>
	<style type="text/css">
	table{
		border-collapse: collapse;
		width:100%;
		color:black;
		font-family: Times New Roman;
		font-size=25px;
		text-align=left;
	}
	th{
		background-color:#91ccb3;
		color:white;
	}
	tr:nth-child(even){
		background-color:#fff5ee;
	}
	td{
		text-align:center;
	}
	</style>
	</head>
	 <body>
		 <table>
			 <tr>
				 <th>Class</th>
				 <th>Class_ID</th>
				 <th>Coach</th>
				 <th>Price</th>
				 <th>Period</th>
				 <th>Allowed_Age</th>
			 </tr>
				 <?php
				 
				$connection=mysqli_connect("localhost", "root", "", "classes_info");
				
				 $mysql="select * from classes";
				 $result = $connection->query($mysql);
				 if ($result->num_rows > 0){
					 while($row = $result->fetch_assoc()){
						 echo "<tr><td>" . $row["Class"] . "</td><td>"
						  . $row["Class_ID"] . "</td><td>"
						  . $row["Coach"] . "</td><td>"
						  . $row["Price"] . "</td><td>"
						  . $row["Period"] . "</td><td>"
						  . $row["Allowed_Age"] . "</td></tr>";
					 } 
				 } else {
					 echo"No data!";
				 }
				 
				 $classes= $_POST["classes"];
				 $period= $_POST["Period"];
				 // $price_month=100;
				 $tax=50;
				 
				 $connection=mysqli_connect("localhost", "root", "", "classes_info");
				
				 $myq="select Price from classes";
				 $price = $connection->query($myq);
				 if ($price->num_rows > 0){
						 if ($classes == "HIIT"){
							switch($period){
							case "1 day at week":
							$price=70+$tax;
							echo" the price is ".($price);
							break;
						
							case "3 months":
						   $price=160*3+$tax;
							echo" the price is ".($price);
							break;
							
							case "6 months":
							$price=260*6+$tax;
							echo" the price is ".($price);
							break;
							
							case "1 year":
							$price=700*12+$tax;
							echo" the price is ".($price);
							break;
							}
						 }
						 
						 if ($classes == "YOGA"){
							switch($period){
							case "1 day at week":
							$price=70+$tax;
							echo" the price is ".($price);
							break;
						
							case "3 months":
						   $price=180*3+$tax;
							echo" the price is ".($price);
							break;
							
							case "6 months":
							$price=605*6+$tax;
							echo" the price is ".($price);
							break;
							
							case "1 year":
							$price=1000*12+$tax;
							echo" the price is ".($price);
							break;
							}
						 }
						 
						 if ($classes == "ZUMBA"){
							switch($period){
							case "1 day at week":
							$price=70+$tax;
							echo" the price is ".($price);
							break;
						
							case "3 months":
						   $price=140*3+$tax;
							echo" the price is ".($price);
							break;
							
							case "6 months":
							$price=400*6+$tax;
							echo" the price is ".($price);
							break;
							
							case "1 year":
							$price=610*12+$tax;
							echo" the price is ".($price);
							break;
							}
						 }
						 
						 if ($classes == "PILATES"){
							switch($period){
							case "1 day at week":
							$price=70+$tax;
							echo" the price is ".($price);
							break;
						
							case "3 months":
						   $price=200*3+$tax;
							echo" the price is ".($price);
							break;
							
							case "6 months":
							$price=600*6+$tax;
							echo" the price is ".($price);
							break;
							
							case "1 year":
							$price=900*12+$tax;
							echo" the price is ".($price);
							break;
							}
						 }
							 
					 } 
				  else {
					 echo"No data!";
				 }
				 
				 ?>
		 </table>
	 </body>
 </html>