<?php

$first= $_POST["first"];
$UserID= $_POST["UserID"];
$email= $_POST["email"];
$telephone= $_POST["telephone"];
$nationality= $_POST["nationality"];
$Gender= $_POST["Gender"];
$date= $_POST["date"];
$age= $_POST["age"];
$language= $_POST["language"];
$TheMessage= $_POST["TheMessage"];
 
 $host= "localhost";
 $p_db="participants_info";
 $username="root";
 $password="";
 $connection=mysqli_connect($host, $username, $password, $p_db);
 if (!$connection){
	 die("Can not connect");
 }
 $insertDB="insert into members (Name, UserID, Email, PhoneNumber, nationality, Gender, Birthdate, age, language, FirstMessage)
  values('$first', '$UserID', '$email', $telephone, '$nationality', '$Gender', $date, $age, '$language', '$TheMessage')";
  mysqli_query($connection, $insertDB);
 echo"Hello $first ! Welcome To Our Website, We Will Contact You Soon :) ";
 